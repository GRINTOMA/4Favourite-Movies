export class Grintoma{
    sid: number;
    sname: string;
    slogin: string;
    scampus: string;
    stitle: string;
}

