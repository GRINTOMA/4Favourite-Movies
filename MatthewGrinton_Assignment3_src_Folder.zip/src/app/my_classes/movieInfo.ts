export class Movie{
    mname: string;
    martist: string;
    mgenre: string;
    mreleased: number;
    mposter: string;
}

